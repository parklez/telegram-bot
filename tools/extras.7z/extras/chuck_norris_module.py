'''
Yet another auto-responder that would inpersonate chuck norris.
'''

import random

from config import *

@bot.message_handler(func=lambda m: True)
def reply_message(message):
    cid = get_user_id(message)
    m = message.text.lower()
    reply_text = ''
    
    if 'que' in m and 'devo' in m and 'fazer' in m and '?' in m:
        reply_text = get_what_to_do_answer()
        users_steps[cid] = ''
    
    elif 'fato' in m:
        reply_text = get_random_fact()
        users_steps[cid] = ''
    
    elif 'história' in m:
        reply_text = get_random_story()
        users_steps[cid] = ''
        
    elif 'historia' in m:
        reply_text = get_random_story()
        users_steps[cid] = ''
        
    elif 'chuck norris' in m:
        for x in ['filha da puta', 'viado', 'corno', 'arrombado,', 'gay']:
            if x in m:
                reply_text = x + ' é você pois eu o permeti viver desta forma. Não venha com gracinhas.'
        

        
        
        
        
        
        
    
    if reply_text:
        bot.send_message(message.chat.id, reply_text)
        
  
    
def get_what_to_do_answer():
    a = ['Nada.', 'Parar de enxer meu saco. Chuck Norris tem muito o que fazer.',
    'Você deveria assistir "Braddock" para aprender o básico do básico antes de tudo.']
    return random.choice(a)
    
def get_random_fact():
    a = ['Quando Alexander Bell criou o telefone, ele viu 3 ligações perdidas minhas.',
    'Eu nunca ligo para o número errado.\nQuem atende é quem pega o telefone errado.',
    'Quando entro uma sala escura, eu não acendo as luzes, apenas espanto o escuro.',
    'O meu calendário vai direto do dia 31 de Março ao dia 2 de Abril. Ninguém faz Chuck Norris de bobo.',
    'Quando um apocalipse zombie começar, não tentarei sobreviver. Os zombies tentarão.',
    'Eu não uso um relógio, eu decido que horas são.',
    'Já contei ao infinito de trás para frente, duas vezes.',
    'Eu já consegui afogar peixes.',
    'Não existe essa coisa de "teoria da evolução", mas sim seres que eu permito viver.',
    'Minhas lágrimas curam cancer. Pena que eu nunca choro.',
    'O motivo pelo qual recém-nascidos choram é porque eles sabem que acabaram de nascer num mundo com Chuck Norris.',
    'Eu já estrangulei terroristas com um telefone sem fio.',
    'Meu carro não precisa de combustível. Ele é anda a partir de medo.']
    return random.choice(a)
    
def get_random_story():
    a = ['Uma vez no café da manhã eu cortei uma faca com a manteiga.',
    'Quando pequeno, queimei formigas com uma lupa durante a noite.',
    'Uma vez uma cobra mordeu minha perna. Depois de 5 dias em dor intensa, a cobra morreu.',
    'Sabe porque não há vida em marte? Bem, tudo começou com um RoundHouseKick...',
    'Uma vez estava a cortar cebolas, e elas começaram a chorar.',
    'Quando criança eu nunca brinquei de "Pega-Pega", mas sim "Reza-Pra-Eu-Não-Te-Pegar".',
    'Quando criança, eu não molhava a cama, a cama se molhava de medo.',
    'Eu tenho gravado a criação da primeira camera de video sendo feita.',
    'Já deram o meu nome à uma rua. Porém tiveram que mudar pois ninguém atravessa Chuck Norris e sai vivo.']
    return random.choice(a)