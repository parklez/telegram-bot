from config import *

import PIL
from PIL import Image, ImageDraw, ImageFont

#Resources
font_impact = ImageFont.truetype('meiryob.ttc', 35, encoding='utf-8')
source_file = 'files/ratinho.jpg'
black = (0,0,0)
white = (255,255,255)

def ratinho_fy(text_input):
    #Open file
    picture = Image.open(source_file)

    ### Draw ###
    draw = ImageDraw.Draw(picture)

    #print('picture.size:', picture.size)
    #print('draw.multilin...:', draw.multiline_textsize(text_input,font=font_impact))

    space = int((picture.size[0] - draw.multiline_textsize(text_input,font=font_impact)[0]) / 2)
    #Shadows
    draw.multiline_text((space-2, 22), text_input, black, font=font_impact, align='center')
    draw.multiline_text((space+2, 22), text_input, black, font=font_impact, align='center')
    draw.multiline_text((space-2, 18), text_input, black, font=font_impact, align='center')
    draw.multiline_text((space+2, 18), text_input, black, font=font_impact, align='center')
    #More shadows
    draw.multiline_text((space+2, 20), text_input, black, font=font_impact, align='center')
    draw.multiline_text((space-2, 20), text_input, black, font=font_impact, align='center')
    draw.multiline_text((space, 18), text_input, black, font=font_impact, align='center')
    draw.multiline_text((space, 22), text_input, black, font=font_impact, align='center')

    #White text
    draw.multiline_text((space, 20), text_input, white, font=font_impact, align='center')

    #Save file
    picture.save('files/ratinho2.jpg')
    
@bot.message_handler(commands=['ratinho'])
def reply_ratinho(message):
    cid = get_user_id(message)
		
    text_to_draw = message.text[8:].upper()
    ratinho_fy(text_to_draw)
    photo = open('files/ratinho2.jpg', 'rb')
    bot.send_photo(message.chat.id, photo)
